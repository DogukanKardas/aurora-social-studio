# Aurora Social Studio

Aurora Vehicles sosyal medya yönetimi için yerel web uygulaması: trend araştırması, içerik planlama, AI görsel ve video üretimi, Canva'ya aktarma ve içerik takvimi.

Paket kurulumu gerekmez. Tek gereken **Node.js 20 veya üstü** (nodejs.org → LTS).

## Çalıştırma

1. `start.bat` dosyasına çift tıkla.
2. Tarayıcıda `http://127.0.0.1:3000` açılır.
3. Kapatmak için siyah pencereyi kapat.

İlk açılışta `.env` dosyası `.env.example`'dan otomatik oluşturulur. Anahtarları oraya yaz, uygulamayı kapatıp yeniden aç. Anahtarı girilmeyen özellik kapalı kalır; diğerleri çalışır.

## Modüller

| Sekme | Ne yapar | Gereken anahtar |
| --- | --- | --- |
| Takvim | Aylık takvim, paylaşım kartları, durum takibi (Fikir → Taslak → Hazır → Zamanlandı → Yayınlandı). İlk 30 günlük plan yüklü gelir. | — |
| İçerik | Marka sesine uygun fikir ve caption üretimi, fikir bankası, tek tıkla takvime ekleme | `ANTHROPIC_API_KEY` |
| Trendler | TrendsMCP araçlarını otomatik listeler ve çalıştırır, sonucu fikir olarak kaydeder | `TRENDS_MCP_URL`, `TRENDS_MCP_KEY` |
| Görsel | AI görsel üretimi, Pexels / Pixabay / Unsplash araması, medya kütüphanesi, Canva'ya aktarma | `REPLICATE_API_TOKEN`, stok anahtarları, Canva |
| Video | Metinden veya kütüphanedeki bir görselden kısa video üretimi | `REPLICATE_API_TOKEN` |

## Canva kurulumu (bir kerelik)

1. canva.com/developers → **Your integrations** → **Create an integration** (Private).
2. **Scopes**: asset read + write, design content read + write, design meta read.
3. **Authentication → Redirect URLs**: `http://127.0.0.1:3000/api/canva/callback`
4. Client ID ve Client Secret'ı `.env`'e yaz, uygulamayı yeniden başlat.
5. Görsel sekmesinde **Canva'yı bağla** → giriş yap.

Sonrasında kütüphanedeki her görsel için **Canva'ya aktar** seçilen ölçüde (4:5, 1:1, 9:16, 16:9) düzenlenebilir bir Canva tasarımı oluşturur ve açar.

## Veriler

- Takvim, fikirler ve kütüphane: `data/db.json`
- Görsel ve videolar: `data/media/`
- Canva oturumu: `data/canva-token.json`

Yedek almak için `data` klasörünü kopyalaman yeterli. Silinen medya dosyaları `_silinen_` önekiyle klasörde kalır.

## Modelleri değiştirmek

`.env` içindeki `REPLICATE_IMAGE_MODEL` ve `REPLICATE_VIDEO_MODEL` değerlerine Replicate'teki herhangi bir resmi modelin adını (`sahip/model`) yazabilirsin. Video modelinin başlangıç görseli parametresi farklıysa `REPLICATE_VIDEO_IMAGE_KEY` değerini değiştir.
