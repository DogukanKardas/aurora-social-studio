// Aurora Social Studio — zero-dependency local server (Node 20+)
// Start: node server.js  →  http://127.0.0.1:3000
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
try { process.loadEnvFile(path.join(ROOT, '.env')); } catch { /* .env optional */ }

const PORT = Number(process.env.PORT || 3000);
const HOST = '127.0.0.1';
const BASE_URL = `http://${HOST}:${PORT}`;
const DATA_DIR = path.join(ROOT, 'data');
const MEDIA_DIR = path.join(DATA_DIR, 'media');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const CANVA_FILE = path.join(DATA_DIR, 'canva-token.json');
fs.mkdirSync(MEDIA_DIR, { recursive: true });

const env = (k, d = '') => (process.env[k] || d).trim();

// ---------------------------------------------------------------- storage
function loadDb() {
  if (!fs.existsSync(DB_FILE)) {
    const seed = require('./seed.js');
    const db = { posts: seed.posts(), ideas: [], media: [], trends: [] };
    saveDb(db);
    return db;
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function saveDb(db) {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
let db = loadDb();
const id = () => crypto.randomBytes(6).toString('hex');
const now = () => new Date().toISOString();

// ---------------------------------------------------------------- http helpers
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.gif': 'image/gif', '.mp4': 'video/mp4', '.webm': 'video/webm', '.svg': 'image/svg+xml',
};
function send(res, status, body, headers = {}) {
  const isBuf = Buffer.isBuffer(body);
  const payload = isBuf || typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': isBuf ? 'application/octet-stream' : (typeof body === 'string' ? 'text/plain; charset=utf-8' : 'application/json'),
    ...headers,
  });
  res.end(payload);
}
const ok = (res, body) => send(res, 200, body);
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const fail = (status, msg) => { throw new HttpError(status, msg); };

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const c of req) { size += c.length; if (size > 25e6) fail(413, 'İstek çok büyük'); chunks.push(c); }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { fail(400, 'Geçersiz JSON'); }
}
function serveFile(res, file) {
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return send(res, 404, 'Bulunamadı');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}
function safeJoin(base, rel) {
  const p = path.normalize(path.join(base, decodeURIComponent(rel)));
  if (!p.startsWith(base + path.sep)) fail(403, 'Yasak');
  return p;
}
async function fetchJson(url, opts = {}, label = 'API') {
  const r = await fetch(url, opts);
  const text = await r.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  if (!r.ok) {
    const msg = typeof data === 'object' ? (data.detail || data.message || data.error?.message || data.error || JSON.stringify(data)) : text;
    fail(502, `${label} hatası (${r.status}): ${String(msg).slice(0, 300)}`);
  }
  return data;
}
function need(key, label) {
  const v = env(key);
  if (!v) fail(400, `${label} için .env dosyasında ${key} tanımlı değil (Ayarlar sekmesine bak).`);
  return v;
}

// ---------------------------------------------------------------- media library
async function downloadToLibrary(url, meta) {
  const r = await fetch(url);
  if (!r.ok) fail(502, `Dosya indirilemedi (${r.status})`);
  const buf = Buffer.from(await r.arrayBuffer());
  const ct = r.headers.get('content-type') || '';
  let ext = path.extname(new URL(url).pathname).toLowerCase();
  if (!MIME[ext]) ext = ct.includes('video') ? '.mp4' : ct.includes('png') ? '.png' : ct.includes('webp') ? '.webp' : '.jpg';
  return addMedia(buf, ext, meta);
}
function addMedia(buf, ext, meta) {
  const mid = id();
  const file = `${mid}${ext}`;
  fs.writeFileSync(path.join(MEDIA_DIR, file), buf);
  const item = {
    id: mid, file, url: `/media/${file}`,
    type: ['.mp4', '.webm'].includes(ext) ? 'video' : 'image',
    createdAt: now(), ...meta,
  };
  db.media.unshift(item);
  saveDb(db);
  return item;
}

// ---------------------------------------------------------------- Claude (content planning)
const BRAND = `You write social media content for Aurora Vehicles Inc., a dash cam sales and professional installation company in Vancouver, BC (8+ years, 3,000+ customers, 50+ dealer partners).
Products: Falcon Vision (4K front, Full HD rear, 1080p cabin), Nova (4K Ultra HD), Hawk Vision (4K, parking-mode recording), AuroraCam. Sony Starvis sensor, f/1.8, 140° FOV.
Services: concealed installation, parking-mode power with battery protection, accessories. Bookings via WhatsApp.
Founding story: the founder's close friend was wrongly blamed for an accident with no footage to prove otherwise.
Voice: premium, calm, restrained, precise. Short sentences. No exclamation marks, no hype, no discount shouting, no fear-mongering, max 1 emoji. Tagline: "Precision in Every Frame".
Content pillars: Kurulum işçiliği (installation craft), Görüntü kalitesi (footage quality), Bilgi ve eğitim (education), Güven ve hikâye (trust & story), Ürün (product).
Captions are in English for a Vancouver audience; end with a soft call to book on WhatsApp; 3-5 local hashtags (e.g. #Vancouver #DashCam #BCDrivers).
Never invent customer testimonials, statistics or prices.`;

async function claude(prompt, maxTokens = 2000) {
  const key = need('ANTHROPIC_API_KEY', 'İçerik üretimi');
  const data = await fetchJson('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: env('ANTHROPIC_MODEL', 'claude-sonnet-5-5'),
      max_tokens: maxTokens,
      system: BRAND + '\nAlways answer with valid JSON only, no markdown fences, no commentary.',
      messages: [{ role: 'user', content: prompt }],
    }),
  }, 'Claude API');
  const text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  const m = text.match(/[\[{][\s\S]*[\]}]/);
  try { return JSON.parse(m ? m[0] : text); } catch { fail(502, 'Claude geçerli JSON döndürmedi, tekrar dene.'); }
}

// ---------------------------------------------------------------- Replicate
async function replicateCreate(model, input, wait) {
  const key = need('REPLICATE_API_TOKEN', 'Replicate');
  const headers = { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' };
  if (wait) headers.Prefer = 'wait=60';
  // "owner/name" → official model endpoint; "owner/name:version" → versioned prediction
  let url, body;
  if (model.includes(':')) {
    url = 'https://api.replicate.com/v1/predictions';
    body = { version: model.split(':')[1], input };
  } else {
    url = `https://api.replicate.com/v1/models/${model}/predictions`;
    body = { input };
  }
  return fetchJson(url, { method: 'POST', headers, body: JSON.stringify(body) }, 'Replicate');
}
async function replicateGet(pid) {
  const key = need('REPLICATE_API_TOKEN', 'Replicate');
  return fetchJson(`https://api.replicate.com/v1/predictions/${encodeURIComponent(pid)}`,
    { headers: { Authorization: `Bearer ${key}` } }, 'Replicate');
}
const outputUrls = o => (Array.isArray(o) ? o : [o]).flat().filter(x => typeof x === 'string' && x.startsWith('http'));
const fileToDataUri = item => {
  const buf = fs.readFileSync(path.join(MEDIA_DIR, item.file));
  return `data:${MIME[path.extname(item.file)] || 'image/jpeg'};base64,${buf.toString('base64')}`;
};

// ---------------------------------------------------------------- stock photos
async function stockSearch(source, q) {
  const query = encodeURIComponent(q);
  if (source === 'pexels') {
    const d = await fetchJson(`https://api.pexels.com/v1/search?query=${query}&per_page=24`,
      { headers: { Authorization: need('PEXELS_API_KEY', 'Pexels') } }, 'Pexels');
    return d.photos.map(p => ({ thumb: p.src.medium, full: p.src.large2x, credit: `Photo by ${p.photographer} on Pexels`, link: p.url }));
  }
  if (source === 'pixabay') {
    const d = await fetchJson(`https://pixabay.com/api/?key=${need('PIXABAY_API_KEY', 'Pixabay')}&q=${query}&per_page=24&image_type=photo&safesearch=true`, {}, 'Pixabay');
    return d.hits.map(h => ({ thumb: h.webformatURL, full: h.largeImageURL, credit: `Image by ${h.user} on Pixabay`, link: h.pageURL }));
  }
  if (source === 'unsplash') {
    const d = await fetchJson(`https://api.unsplash.com/search/photos?query=${query}&per_page=24`,
      { headers: { Authorization: `Client-ID ${need('UNSPLASH_ACCESS_KEY', 'Unsplash')}` } }, 'Unsplash');
    return d.results.map(p => ({
      thumb: p.urls.small, full: p.urls.regular, credit: `Photo by ${p.user.name} on Unsplash`,
      link: p.links.html, track: p.links.download_location,
    }));
  }
  fail(400, 'Bilinmeyen kaynak');
}

// ---------------------------------------------------------------- Trends (MCP over streamable HTTP)
let mcpSession = null;
async function mcpRequest(method, params, isNotification = false) {
  const url = need('TRENDS_MCP_URL', 'Trend araştırması');
  const headers = { 'Content-Type': 'application/json', Accept: 'application/json, text/event-stream' };
  const key = env('TRENDS_MCP_KEY');
  if (key) {
    let prefix = process.env.TRENDS_MCP_AUTH_PREFIX === undefined ? 'Bearer' : process.env.TRENDS_MCP_AUTH_PREFIX.trim();
    if (prefix) prefix += ' ';
    headers[env('TRENDS_MCP_AUTH_HEADER', 'Authorization')] = prefix + key;
  }
  if (mcpSession) headers['Mcp-Session-Id'] = mcpSession;
  const msg = { jsonrpc: '2.0', method, ...(params ? { params } : {}) };
  const rid = isNotification ? null : Math.floor(Math.random() * 1e9);
  if (!isNotification) msg.id = rid;
  const r = await fetch(url, { method: 'POST', headers, body: JSON.stringify(msg) });
  const sid = r.headers.get('mcp-session-id');
  if (sid) mcpSession = sid;
  if (isNotification) return null;
  const text = await r.text();
  if (!r.ok) { if (r.status === 404) mcpSession = null; fail(502, `Trends MCP hatası (${r.status}): ${text.slice(0, 300)}`); }
  let reply = null;
  if ((r.headers.get('content-type') || '').includes('text/event-stream')) {
    for (const line of text.split('\n')) {
      if (!line.startsWith('data:')) continue;
      try { const m = JSON.parse(line.slice(5).trim()); if (m.id === rid) reply = m; } catch { }
    }
  } else { try { reply = JSON.parse(text); } catch { } }
  if (!reply) fail(502, 'Trends MCP yanıtı okunamadı');
  if (reply.error) fail(502, `Trends MCP: ${reply.error.message || JSON.stringify(reply.error)}`);
  return reply.result;
}
async function mcpEnsure() {
  if (mcpSession) return;
  await mcpRequest('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'aurora-social-studio', version: '1.0.0' } });
  await mcpRequest('notifications/initialized', null, true);
}
async function mcpCall(method, params) {
  try { await mcpEnsure(); return await mcpRequest(method, params); }
  catch (e) { mcpSession = null; await mcpEnsure(); return mcpRequest(method, params); }
}

// ---------------------------------------------------------------- Canva Connect
const CANVA_SCOPES = 'asset:read asset:write design:content:read design:content:write design:meta:read';
const CANVA_REDIRECT = `${BASE_URL}/api/canva/callback`;
const canvaPending = new Map(); // state -> verifier
const b64url = b => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const readCanva = () => (fs.existsSync(CANVA_FILE) ? JSON.parse(fs.readFileSync(CANVA_FILE, 'utf8')) : null);
const writeCanva = t => fs.writeFileSync(CANVA_FILE, JSON.stringify(t, null, 2));
async function canvaToken(params) {
  const cid = need('CANVA_CLIENT_ID', 'Canva'); const sec = need('CANVA_CLIENT_SECRET', 'Canva');
  const d = await fetchJson('https://api.canva.com/rest/v1/oauth/token', {
    method: 'POST',
    headers: { Authorization: 'Basic ' + Buffer.from(`${cid}:${sec}`).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
  }, 'Canva');
  const t = { access_token: d.access_token, refresh_token: d.refresh_token, expires_at: Date.now() + (d.expires_in - 60) * 1000 };
  writeCanva(t);
  return t;
}
async function canvaAccess() {
  let t = readCanva();
  if (!t) fail(401, 'Canva bağlı değil. Önce "Canva\'yı bağla" butonuna bas.');
  if (Date.now() > t.expires_at) t = await canvaToken({ grant_type: 'refresh_token', refresh_token: t.refresh_token });
  return t.access_token;
}
async function canvaExport(item) {
  const token = await canvaAccess();
  const buf = fs.readFileSync(path.join(MEDIA_DIR, item.file));
  const name = (item.title || item.prompt || item.file).slice(0, 50);
  let job = await fetchJson('https://api.canva.com/rest/v1/asset-uploads', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`, 'Content-Type': 'application/octet-stream',
      'Asset-Upload-Metadata': JSON.stringify({ name_base64: Buffer.from(name).toString('base64') }),
    },
    body: buf,
  }, 'Canva yükleme');
  job = job.job;
  for (let i = 0; i < 60 && job.status === 'in_progress'; i++) {
    await new Promise(r => setTimeout(r, 1500));
    job = (await fetchJson(`https://api.canva.com/rest/v1/asset-uploads/${job.id}`, { headers: { Authorization: `Bearer ${token}` } }, 'Canva')).job;
  }
  if (job.status !== 'success') fail(502, `Canva yükleme tamamlanmadı: ${job.error?.message || job.status}`);
  const size = { square: [1080, 1080], portrait: [1080, 1350], story: [1080, 1920], landscape: [1920, 1080] }[item.canvaSize || 'portrait'];
  const d = await fetchJson('https://api.canva.com/rest/v1/designs', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ design_type: { type: 'custom', width: size[0], height: size[1] }, asset_id: job.asset.id, title: `Aurora — ${name}` }),
  }, 'Canva tasarım');
  return d.design.urls.edit_url;
}

// ---------------------------------------------------------------- video jobs (in memory)
const videoJobs = new Map();

// ---------------------------------------------------------------- router
const routes = [];
const route = (method, pattern, handler) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler });

route('GET', '/api/status', () => ({
  claude: !!env('ANTHROPIC_API_KEY'), replicate: !!env('REPLICATE_API_TOKEN'),
  pexels: !!env('PEXELS_API_KEY'), pixabay: !!env('PIXABAY_API_KEY'), unsplash: !!env('UNSPLASH_ACCESS_KEY'),
  trends: !!env('TRENDS_MCP_URL'), canvaApp: !!(env('CANVA_CLIENT_ID') && env('CANVA_CLIENT_SECRET')), canvaConnected: !!readCanva(),
  imageModel: env('REPLICATE_IMAGE_MODEL', 'black-forest-labs/flux-schnell'),
  videoModel: env('REPLICATE_VIDEO_MODEL', 'minimax/video-01'),
  canvaRedirect: CANVA_REDIRECT,
}));

// posts (calendar)
const POST_FIELDS = ['date', 'time', 'platforms', 'format', 'pillar', 'topic', 'caption', 'status', 'mediaIds', 'notes'];
const pick = (o, keys) => Object.fromEntries(keys.filter(k => k in o).map(k => [k, o[k]]));
route('GET', '/api/posts', () => db.posts);
route('POST', '/api/posts', async (req) => {
  const b = await readJson(req);
  if (!b.date) fail(400, 'Tarih gerekli');
  const p = { id: id(), platforms: [], mediaIds: [], status: 'Fikir', time: '18:00', ...pick(b, POST_FIELDS), createdAt: now() };
  db.posts.push(p); saveDb(db); return p;
});
route('PUT', '/api/posts/:id', async (req, { id: pid }) => {
  const p = db.posts.find(x => x.id === pid) || fail(404, 'Paylaşım yok');
  Object.assign(p, pick(await readJson(req), POST_FIELDS), { updatedAt: now() }); saveDb(db); return p;
});
route('DELETE', '/api/posts/:id', (req, { id: pid }) => { db.posts = db.posts.filter(x => x.id !== pid); saveDb(db); return { ok: true }; });

// ideas (content planning)
route('GET', '/api/ideas', () => db.ideas);
route('POST', '/api/ideas', async (req) => {
  const b = await readJson(req);
  const i = { id: id(), title: b.title || 'Yeni fikir', pillar: b.pillar || '', platform: b.platform || '', format: b.format || '', caption: b.caption || '', notes: b.notes || '', createdAt: now() };
  db.ideas.unshift(i); saveDb(db); return i;
});
route('DELETE', '/api/ideas/:id', (req, { id: iid }) => { db.ideas = db.ideas.filter(x => x.id !== iid); saveDb(db); return { ok: true }; });
route('POST', '/api/ideas/generate', async (req) => {
  const b = await readJson(req);
  const count = Math.min(Math.max(Number(b.count) || 6, 1), 12);
  const out = await claude(`Generate ${count} distinct social media post ideas.
Focus / brief: ${b.brief || 'a balanced mix across all pillars'}
${b.pillar ? `Pillar: ${b.pillar}` : ''}${b.platform ? `\nPlatform: ${b.platform}` : ''}
Return a JSON array of objects with keys: "title" (Turkish, short topic), "pillar" (one of the 5 Turkish pillar names), "platform" (Instagram, Facebook, YouTube or LinkedIn), "format" (Reel, Carousel, Görsel, Short, Uzun video, Metin + görsel), "caption" (English, ready to post), "notes" (Turkish, what to shoot or prepare).`, 3000);
  const list = (Array.isArray(out) ? out : out.ideas || []).map(x => ({ id: id(), title: x.title, pillar: x.pillar, platform: x.platform, format: x.format, caption: x.caption, notes: x.notes, createdAt: now() }));
  db.ideas.unshift(...list); saveDb(db); return list;
});
route('POST', '/api/caption', async (req) => {
  const b = await readJson(req);
  return claude(`Write 3 alternative captions for this post.
Topic: ${b.topic || ''}\nPlatform(s): ${(b.platforms || []).join(', ') || 'Instagram'}\nFormat: ${b.format || ''}\nPillar: ${b.pillar || ''}\nNotes: ${b.notes || ''}
Adapt length to the platform (LinkedIn: professional B2B tone for dealers/fleets; YouTube: title-like first line).
Return JSON: {"captions": ["...", "...", "..."]}`);
});

// trends
route('GET', '/api/trends/tools', async () => (await mcpCall('tools/list', {})).tools || []);
route('POST', '/api/trends/call', async (req) => {
  const b = await readJson(req);
  if (!b.tool) fail(400, 'Araç seç');
  const r = await mcpCall('tools/call', { name: b.tool, arguments: b.args || {} });
  const text = (r.content || []).map(c => c.text || (c.type === 'resource' ? JSON.stringify(c.resource) : '')).join('\n');
  const entry = { id: id(), tool: b.tool, args: b.args || {}, text, createdAt: now() };
  db.trends.unshift(entry); db.trends = db.trends.slice(0, 50); saveDb(db);
  return entry;
});
route('GET', '/api/trends/history', () => db.trends);

// stock + media
route('GET', '/api/stock', (req, p, url) => stockSearch(url.searchParams.get('source'), url.searchParams.get('q') || 'dash cam'));
route('POST', '/api/media/import', async (req) => {
  const b = await readJson(req);
  if (!b.url) fail(400, 'URL gerekli');
  if (b.track && env('UNSPLASH_ACCESS_KEY')) { // Unsplash API guideline: trigger download endpoint
    fetch(b.track, { headers: { Authorization: `Client-ID ${env('UNSPLASH_ACCESS_KEY')}` } }).catch(() => { });
  }
  return downloadToLibrary(b.url, { source: b.source || 'stok', credit: b.credit || '', link: b.link || '', title: b.title || '' });
});
route('POST', '/api/media/upload', async (req) => {
  const b = await readJson(req); // {name, dataUri}
  const m = /^data:([^;]+);base64,(.+)$/.exec(b.dataUri || '') || fail(400, 'Dosya okunamadı');
  const ext = path.extname(b.name || '').toLowerCase() || (m[1].includes('video') ? '.mp4' : '.jpg');
  if (!MIME[ext]) fail(400, 'Desteklenmeyen dosya türü');
  return addMedia(Buffer.from(m[2], 'base64'), ext, { source: 'yükleme', title: b.name || '' });
});
route('GET', '/api/media', () => db.media);
route('PUT', '/api/media/:id', async (req, { id: mid }) => {
  const m = db.media.find(x => x.id === mid) || fail(404, 'Medya yok');
  const b = await readJson(req);
  Object.assign(m, pick(b, ['title', 'canvaSize'])); saveDb(db); return m;
});
route('DELETE', '/api/media/:id', (req, { id: mid }) => {
  const m = db.media.find(x => x.id === mid);
  if (m) { try { fs.renameSync(path.join(MEDIA_DIR, m.file), path.join(MEDIA_DIR, '_silinen_' + m.file)); } catch { } }
  db.media = db.media.filter(x => x.id !== mid);
  db.posts.forEach(p => { p.mediaIds = (p.mediaIds || []).filter(x => x !== mid); });
  saveDb(db); return { ok: true };
});

// image generation
route('POST', '/api/image/generate', async (req) => {
  const b = await readJson(req);
  if (!b.prompt) fail(400, 'Açıklama gerekli');
  const model = env('REPLICATE_IMAGE_MODEL', 'black-forest-labs/flux-schnell');
  const input = { prompt: b.prompt, aspect_ratio: b.aspect_ratio || '4:5', num_outputs: Math.min(Number(b.count) || 1, 4), output_format: 'jpg' };
  let pred = await replicateCreate(model, input, true);
  for (let i = 0; i < 60 && !['succeeded', 'failed', 'canceled'].includes(pred.status); i++) {
    await new Promise(r => setTimeout(r, 2000)); pred = await replicateGet(pred.id);
  }
  if (pred.status !== 'succeeded') fail(502, `Görsel üretilemedi: ${pred.error || pred.status}`);
  const items = [];
  for (const u of outputUrls(pred.output)) items.push(await downloadToLibrary(u, { source: 'replicate', prompt: b.prompt, title: b.prompt.slice(0, 60), model }));
  return items;
});

// video generation (async)
route('POST', '/api/video/generate', async (req) => {
  const b = await readJson(req);
  if (!b.prompt) fail(400, 'Açıklama gerekli');
  const model = env('REPLICATE_VIDEO_MODEL', 'minimax/video-01');
  const input = { prompt: b.prompt };
  if (b.imageId) {
    const m = db.media.find(x => x.id === b.imageId && x.type === 'image') || fail(404, 'Başlangıç görseli yok');
    input[env('REPLICATE_VIDEO_IMAGE_KEY', 'first_frame_image')] = fileToDataUri(m);
  }
  const pred = await replicateCreate(model, input, false);
  const job = { id: pred.id, prompt: b.prompt, model, status: pred.status, createdAt: now() };
  videoJobs.set(pred.id, job);
  return job;
});
route('GET', '/api/video/jobs', () => [...videoJobs.values()].reverse());
route('GET', '/api/video/jobs/:id', async (req, { id: pid }) => {
  const job = videoJobs.get(pid) || { id: pid, prompt: '', model: '' };
  if (job.mediaId || job.status === 'failed') return job;
  const pred = await replicateGet(pid);
  job.status = pred.status; job.error = pred.error || null;
  if (pred.status === 'succeeded' && !job.mediaId) {
    const u = outputUrls(pred.output)[0];
    if (u) { const m = await downloadToLibrary(u, { source: 'replicate', prompt: job.prompt, title: job.prompt.slice(0, 60), model: job.model }); job.mediaId = m.id; job.url = m.url; }
  }
  videoJobs.set(pid, job);
  return job;
});

// Canva
route('GET', '/api/canva/connect', (req, p, url, res) => {
  const cid = need('CANVA_CLIENT_ID', 'Canva');
  const verifier = b64url(crypto.randomBytes(64));
  const state = b64url(crypto.randomBytes(16));
  canvaPending.set(state, verifier);
  const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
  const q = new URLSearchParams({ code_challenge: challenge, code_challenge_method: 's256', scope: CANVA_SCOPES, response_type: 'code', client_id: cid, redirect_uri: CANVA_REDIRECT, state });
  res.writeHead(302, { Location: `https://www.canva.com/api/oauth/authorize?${q}` }); res.end();
  return undefined;
});
route('GET', '/api/canva/callback', async (req, p, url, res) => {
  const state = url.searchParams.get('state'); const code = url.searchParams.get('code');
  const verifier = canvaPending.get(state);
  if (!code || !verifier) { send(res, 400, `Canva bağlantısı başarısız: ${url.searchParams.get('error') || 'geçersiz durum'}`); return undefined; }
  canvaPending.delete(state);
  await canvaToken({ grant_type: 'authorization_code', code, code_verifier: verifier, redirect_uri: CANVA_REDIRECT });
  res.writeHead(302, { Location: '/#gorsel' }); res.end();
  return undefined;
});
route('POST', '/api/canva/disconnect', () => { try { fs.unlinkSync(CANVA_FILE); } catch { } return { ok: true }; });
route('POST', '/api/canva/export/:id', async (req, { id: mid }) => {
  const m = db.media.find(x => x.id === mid) || fail(404, 'Medya yok');
  const b = await readJson(req);
  if (b.canvaSize) m.canvaSize = b.canvaSize;
  m.canvaUrl = await canvaExport(m);
  saveDb(db);
  return { editUrl: m.canvaUrl };
});

// ---------------------------------------------------------------- server
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, BASE_URL);
  try {
    if (url.pathname.startsWith('/api/')) {
      for (const r of routes) {
        const m = r.method === req.method && r.re.exec(url.pathname);
        if (!m) continue;
        const out = await r.handler(req, m.groups || {}, url, res);
        if (out !== undefined) ok(res, out);
        return;
      }
      fail(404, 'Bilinmeyen istek');
    }
    if (url.pathname.startsWith('/media/')) return serveFile(res, safeJoin(MEDIA_DIR, url.pathname.slice(7)));
    const rel = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
    return serveFile(res, safeJoin(path.join(ROOT, 'public'), rel));
  } catch (e) {
    if (!res.headersSent) send(res, e.status || 500, { error: e.message || String(e) });
    if (!e.status) console.error(e);
  }
});
server.listen(PORT, HOST, () => console.log(`\n  Aurora Social Studio çalışıyor → ${BASE_URL}\n  Kapatmak için bu pencereyi kapat (veya Ctrl+C).\n`));
