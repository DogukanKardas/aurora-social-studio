# Aurora Social Studio

Aurora Vehicles sosyal medya yönetimi için web uygulaması: trend araştırması, içerik planlama, AI görsel ve video üretimi, Canva'ya aktarma ve içerik takvimi.

- **Canlı:** Vercel'de çalışır, kullanıcı adı ve şifreyle korunur.
- **Veri:** Takvim, fikirler ve medya Supabase'de (`aurora-social-studio` projesi) durur.
- **Paket kurulumu yok:** Yalnızca Node.js yerleşik modülleri kullanılır.

## Yapı

| Dosya | Görev |
| --- | --- |
| `lib/app.js` | Tüm uygulama mantığı (API, giriş, depolama, entegrasyonlar) |
| `api/index.js` | Vercel giriş noktası |
| `server.js` + `start.bat` | Yerelde çalıştırma (`http://127.0.0.1:3000`) |
| `public/` | Arayüz (takvim, içerik, trendler, görsel, video, ayarlar, giriş) |
| `seed.js` | İlk açılışta takvime yüklenen 30 günlük plan |

## Ortam değişkenleri

Tam liste `.env.example` içinde. Vercel'de **Project Settings → Environment Variables** altında, yerelde `.env` dosyasında durur. Bir anahtar eksikse o özellik kapalı kalır, diğerleri çalışır. Durumları uygulamadaki **Ayarlar** sekmesi gösterir.

## Canva kurulumu (bir kerelik)

1. canva.com/developers → **Your integrations** → **Create an integration** (Private).
2. **Scopes**: asset read + write, design content read + write, design meta read.
3. **Redirect URL**: Ayarlar sekmesinde yazan adres (`https://<uygulama>/api/canva/callback`). Yerelde de kullanacaksan `http://127.0.0.1:3000/api/canva/callback` adresini de ekle.
4. Client ID ve Secret'ı ortam değişkenlerine ekle, Görsel sekmesinde **Canva'yı bağla**.

## Veritabanı

Tek tablo: `items(collection, id, data jsonb, created_at)`. RLS açık ve politikasız, yani yalnızca sunucudaki secret key erişebilir. Medya, `media` adlı herkese açık bir Storage klasöründe rastgele adlarla durur.
